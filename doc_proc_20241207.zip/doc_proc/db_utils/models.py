import uuid
from typing import List
from datetime import datetime
from sqlalchemy import String, Integer, ForeignKey, Float, TIMESTAMP, Enum
from sqlalchemy.orm import DeclarativeBase, relationship, Mapped, mapped_column
from ..time_utils import get_current_time


class Base(DeclarativeBase):
    pass


class File(Base):
    """
    name: the name of the file (only the filename without the path, for example: "test.pdf")
    n_pages: the number of pages in the file
    size: the size of the file in MB
    process_type: the type of the file, now only two categories: 'text' and 'image+text', can be added more in the future
    status: ["wait-for-process", "processed", "wait-for-delete", "deleted", "failed"]
    last_change_at: the last time the file is changed (be added, be processed, be deleted)
    """

    __tablename__ = "file"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String, nullable=False)
    n_pages: Mapped[int] = mapped_column(Integer, nullable=False)
    size: Mapped[float] = mapped_column(Float, nullable=False)
    process_type: Mapped[str] = mapped_column(String, nullable=False)
    status: Mapped[Enum] = mapped_column(
        Enum(
            "wait-for-process",
            "processed",
            "wait-for-delete",
            "deleted",
            "failed",
            name="file_status_enum",
        ),
        nullable=False,
        default="wait-for-process",
    )
    last_change_at: Mapped[datetime] = mapped_column(
        TIMESTAMP, nullable=False, default=get_current_time()
    )

    split_files: Mapped[List["SplitFile"]] = relationship(
        "SplitFile", back_populates="file", cascade="all, delete-orphan", lazy="select"
    )


class SplitFile(Base):
    """
    If the page number of file is larger than 200, the original file (File) will be split into multiple SplitFile.
    If the page number of file is less than or equal to 200, the original file (File) still have one SplitFile, and the split_id of the SplitFile is 0.

    id: the id of the split file, the primary key of the table
    split_id: the id of the split file, the first split file has split_id=0, the second split file has split_id=1, and so on
    start_page_number: the start page number of the split file
    n_pages: the number of pages in the split file
    name: the name of the split file, follow the format: {original_file_name}-{split_id}.pdf (for example: test-0.pdf)
    status: ["wait-for-pymupdf4llm", "wait-for-di", "di-processing", "di-processed", "processed", "wait-for-delete", "deleted", "failed"]
    last_change_at: the last time the file is changed (be added, be processed, be deleted)
    pkl_name: the name of the pickle file that contains the DI result, {name}.pkl
    """

    __tablename__ = "split_file"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    split_id: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    start_page_number: Mapped[int] = mapped_column(Integer, nullable=False)
    n_pages: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String, nullable=False)
    status: Mapped[Enum] = mapped_column(
        Enum(
            "wait-for-pymupdf4llm",
            "wait-for-di",
            "di-processing",
            "di-success",
            "di-failed",
            "processed",
            "wait-for-delete",
            "deleted",
            "failed",
            name="splitfile_status_enum",
        ),
        nullable=False,
        default="wait-for-process",
    )
    last_change_at: Mapped[datetime] = mapped_column(
        TIMESTAMP, nullable=False, default=datetime.now(TAIPEI_ZONEINFO)
    )
    pkl_name: Mapped[str] = mapped_column(String, nullable=True)

    file_id: Mapped[int] = mapped_column(Integer, ForeignKey("file.id"), index=True)
    file: Mapped["File"] = relationship("File", lazy="select")
    pages: Mapped[List["Page"]] = relationship(
        "Page", back_populates="split_file", cascade="all, delete-orphan", lazy="select"
    )
    chunks: Mapped[List["Chunk"]] = relationship(
        "Chunk",
        back_populates="split_file",
        cascade="all, delete-orphan",
        lazy="select",
    )
    di_requests: Mapped[List["DIRequest"]] = relationship(
        "DIRequest",
        back_populates="split_file",
        cascade="all, delete-orphan",
        lazy="select",
    )


class Page(Base):
    """
    If the file is deleted, the corresponding pages will be deleted (remove from the database).
    If the file is updated, the corresponding pages will be deleted (remove from the database) and re-added.

    id: the id of the page, the primary key of the table
    page_number: the page number of the page in the file (original file not the split file)
    raw_md_name: the name of the raw markdown file (raw extracted from Azure Document Intelligence Result)
    refined_md_name: the name of the refined markdown file (refined by re-insert tables and figures)
    status: ["wait-for-process-first-md", "wait-for-process-second-md", "processed", "wait-for-delete", "deleted", "failed"]
    """

    __tablename__ = "page"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    page_number: Mapped[int] = mapped_column(Integer, nullable=False)
    raw_md_name: Mapped[str] = mapped_column(String, nullable=False)
    refined_md_name: Mapped[str] = mapped_column(String, nullable=True)
    status: Mapped[Enum] = mapped_column(
        Enum(
            "wait-for-process-first-md",
            "wait-for-process-second-md",
            "processed",
            "wait-for-delete",
            "deleted",
            "failed",
            name="page_status_enum",
        ),
        nullable=False,
        default="wait-for-process-first-md",
    )
    file_id: Mapped[int] = mapped_column(Integer, ForeignKey("file.id"), index=True)
    split_file_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("split_file.id"), index=True
    )
    split_file: Mapped["SplitFile"] = relationship("SplitFile", lazy="select")

    tables: Mapped[List["Table"]] = relationship(
        "Table", back_populates="page", cascade="all, delete-orphan", lazy="select"
    )
    figures: Mapped[List["Figure"]] = relationship(
        "Figure", back_populates="page", cascade="all, delete-orphan", lazy="select"
    )


class Table(Base):
    """
    If the page is deleted, the corresponding tables will be deleted (remove from the database).

    id: the id of the table, the primary key of the table
    file_id: the id of the file that the table belongs to
    split_file_id: the id of the split file that the table belongs to
    page_id: the id of the page that the table belongs to
    table_id_in_page: the id of the table in the page
    table_name: the name of the table (if any) example: table-{page_number}-{table_id_in_page}.md
    """

    __tablename__ = "table"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    page_id: Mapped[int] = mapped_column(Integer, ForeignKey("page.id"), index=True)
    table_id_in_page: Mapped[int] = mapped_column(Integer, nullable=False)
    table_name: Mapped[str] = mapped_column(String, nullable=True)
    page: Mapped["Page"] = relationship("Page", back_populates="tables", lazy="select")


class Figure(Base):
    """
    If the page is deleted, the corresponding figures will be deleted (remove from the database).

    id: the id of the figure, the primary key of the figure
    file_id: the id of the file that the figure belongs to
    split_file_id: the id of the split file that the figure belongs to
    page_id: the id of the page that the figure belongs to
    figure_id_in_page: the id of the figure in the page
    figure_name: the name of the figure (if any) example: figure-{page_number}-{figure_id_in_page}.md
    description: the description of the figure by gpt-4o
    """

    __tablename__ = "figure"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    page_id: Mapped[int] = mapped_column(Integer, ForeignKey("page.id"), index=True)
    figure_id_in_page: Mapped[int] = mapped_column(Integer, nullable=False)
    figure_name: Mapped[str] = mapped_column(String, nullable=True)
    description: Mapped[str] = mapped_column(String, nullable=True)
    page: Mapped["Page"] = relationship("Page", back_populates="figures", lazy="select")


class Chunk(Base):
    """
    status: ["wait-for-upload", "uploaded", "wait-for-delete", "deleted"]
    wait-for-upload: waiting for uploading to Azure AI Search
    uploaded: uploaded to Azure AI Search
    wait-for-delete: waiting for deletion from Azure AI Search
    deleted: deleted from Azure AI Search
    """

    __tablename__ = "chunk"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    file_id: Mapped[int] = mapped_column(Integer, ForeignKey("file.id"), index=True)
    split_file_id: Mapped[int] = mapped_column(Integer, ForeignKey("split_file.id"))
    split_file: Mapped["SplitFile"] = relationship(
        "SplitFile", back_populates="chunks", lazy="select"
    )
    ai_search_id: Mapped[str] = mapped_column(
        String(36), nullable=False, default=lambda: str(uuid.uuid4()), index=True
    )
    content: Mapped[str] = mapped_column(String, nullable=True)
    status: Mapped[Enum] = mapped_column(
        Enum(
            "wait-for-upload",
            "uploaded",
            "wait-for-delete",
            "deleted",
            name="chunk_status_enum",
        ),
        nullable=False,
        default="wait-for-upload",
    )


class DIRequest(Base):
    """
    status: ["processing", "success", "failed", "over-max-wait-time"]
    """

    __tablename__ = "di_request"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    request_at: Mapped[datetime] = mapped_column(TIMESTAMP, nullable=True)
    finish_at: Mapped[datetime] = mapped_column(TIMESTAMP, nullable=True)
    status: Mapped[Enum] = mapped_column(
        Enum(
            "processing",
            "success",
            "failed",
            "over-max-wait-time",
            name="di_request_status_enum",
        ),
        nullable=False,
        default="processing",
    )
    split_file_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("split_file.id"), index=True
    )
    split_file: Mapped["SplitFile"] = relationship(
        "SplitFile", back_populates="di_request", lazy="select"
    )
