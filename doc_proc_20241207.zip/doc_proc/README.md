# Document Intelligence

```bash
conda activate winbond1207
```
