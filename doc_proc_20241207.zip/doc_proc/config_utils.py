import os
from pathlib import Path
import yaml
from dotenv import load_dotenv, find_dotenv


class TiktokenCacheDirNotExistsError(Exception):
    pass


class RootConfig:
    def __init__(self, config_path: str = None) -> None:
        # Load environment variables from a .env file if found
        load_dotenv(find_dotenv())

        # Get CONFIG_PATH from environment if not provided
        config_path = config_path or os.getenv("CONFIG_PATH")

        if not config_path:
            raise ValueError(
                "CONFIG_PATH environment variable is not set or no config path was provided."
            )

        try:
            # Load the YAML configuration file
            with open(config_path, "r") as config_file:
                self._config = yaml.safe_load(config_file)
        except FileNotFoundError:
            raise FileNotFoundError(f"Configuration file not found at {config_path}")
        except PermissionError:
            raise PermissionError(
                f"Permission denied while trying to read the config file at {config_path}"
            )
        except yaml.YAMLError as e:
            raise ValueError(f"Error parsing YAML configuration: {e}")

    @property
    def config(self):
        """Provides access to the loaded configuration."""
        return self._config


class PathConfig:
    def __init__(self):
        """
        Initializes the PathConfigAgent with the provided configuration.
        Args:
            config (dict): The configuration loaded from the YAML file.
        """
        self.config = RootConfig().config
        self._base_dir = Path(self._get_path_from_config("paths", "base"))

    def _get_path_from_config(self, *keys: str) -> str:
        """
        Helper method to retrieve a nested path from the configuration using provided keys.
        Args:
            keys: The hierarchical keys to reach the desired path.
        Returns:
            str: The retrieved path as a string.
        """
        path = self.config
        for key in keys:
            path = path.get(key)
            if path is None:
                raise KeyError(f"Key {'/'.join(keys)} not found in configuration.")
        return path

    @property
    def base_dir(self) -> Path:
        """Returns the base directory path."""
        return self._base_dir

    def get_source_dir(self, process_type: str) -> Path:
        """
        process_type: text, text_image
        """
        return self._base_dir / self._get_path_from_config(
            "paths", f"{process_type}_dir", "base"
        )

    def get_wait_dir(self, process_type: str) -> Path:
        """
        process_type: text, text_image
        """
        return self.get_source_dir(process_type) / self._get_path_from_config(
            "paths", f"{process_type}_dir", "wait_dir"
        )

    def get_done_dir(self, process_type: str) -> Path:
        """
        process_type: text, text_image
        """
        return self.get_source_dir(process_type) / self._get_path_from_config(
            "paths", f"{process_type}_dir", "done_dir"
        )

    @property
    def log_dir_path(self) -> Path:
        """Returns the log directory path."""
        return self.base_dir / self._get_path_from_config("paths", "log_dir")

    @property
    def sql_db_path(self) -> Path:
        """Returns the SQL database directory path."""
        return self.base_dir / self._get_path_from_config("paths", "sql_db")

    @property
    def split_dir_path(self) -> Path:
        """Returns the metadata directory path."""
        return self.base_dir / self._get_path_from_config("paths", "split_dir")

    def get_general_path(self, *path_keys: str) -> Path:
        """
        General method to retrieve a path based on any number of path keys.
        Args:
            path_keys: The hierarchical keys to reach the desired path.
        Returns:
            Path: The constructed Path object.
        """
        return self.base_dir / self._get_path_from_config(*path_keys)

    def get_file_in_dir(self, dir_key: str, filename: str) -> Path:
        """
        Returns the full path to a file located in the specified directory.
        Args:
            dir_key (str): The directory key in the configuration.
            filename (str): The file name.
        Returns:
            Path: Full path to the file.
        """
        return self.get_general_path("paths", "data_dir", dir_key) / filename


class DocumentIntelligenceConfig:
    def __init__(self) -> None:
        self.config = RootConfig().config

    @property
    def endpoint(self) -> str:
        return self.config["document_intelligence"]["endpoint"]

    @property
    def api_key(self) -> str:
        return self.config["document_intelligence"]["api_key"]

    @property
    def api_version(self) -> str:
        return self.config["document_intelligence"]["api_version"]


class AzureOpenAIConfig:

    def __init__(self) -> None:
        self.config = RootConfig().config

    @property
    def endpoint(self) -> str:
        return self.config["azure_openai"]["endpoint"]

    @property
    def api_key(self) -> str:
        return self.config["azure_openai"]["api_key"]

    @property
    def deployment(self) -> str:
        return self.config["azure_openai"]["deployment"]

    @property
    def api_version(self) -> str:
        return self.config["azure_openai"]["api_version"]


class ImageAOAIConfig:

    def __init__(self) -> None:
        self.config = RootConfig().config

    @property
    def api_key(self) -> str:
        return self.config["image_aoai"]["api_key"]

    @property
    def endpoint(self) -> str:
        return self.config["image_aoai"]["endpoint"]

    @property
    def deployment(self) -> str:
        return self.config["image_aoai"]["deployment"]

    @property
    def api_version(self) -> str:
        return self.config["image_aoai"]["api_version"]


class EmbeddingConfig:
    d_embedding_dimension = {
        "text-embedding-ada-002": 1536,
        "text-embedding-3-small": 1536,
        "text-embedding-3-large": 3072,
    }

    def __init__(self) -> None:
        self.config = RootConfig().config

    @property
    def model(self) -> str:
        return self.config["embedding"]["model"]

    @property
    def deployment(self) -> str:
        return self.config["embedding"]["model"]

    @property
    def api_version(self) -> str:
        return self.config["embedding"]["api_version"]

    @property
    def api_key(self) -> str:
        return self.config["embedding"]["api_key"]

    @property
    def endpoint(self) -> str:
        return self.config["embedding"]["endpoint"]

    @property
    def dimension(self) -> int:
        return self.d_embedding_dimension[self.model]


class AzureAISearchConfig:

    def __init__(self) -> None:
        self.config = RootConfig().config

    @property
    def index_name(self) -> str:
        return self.config["azure_ai_search"]["index_name"]

    @property
    def endpoint(self) -> str:
        return self.config["azure_ai_search"]["endpoint"]

    @property
    def api_version(self) -> str:
        return self.config["azure_ai_search"]["api_version"]

    @property
    def api_key(self) -> str:
        return self.config["azure_ai_search"]["api_key"]


class ChunkingConfig:
    def __init__(self) -> None:
        self.config = RootConfig().config

    @property
    def model_name(self) -> str:
        return self.config["chunking"]["model_name"]

    @property
    def chunk_size(self) -> int:
        return self.config["chunking"]["chunk_size"]

    @property
    def chunk_overlap(self) -> int:
        return self.config["chunking"]["chunk_overlap"]


class TiktokenConfig:
    def __init__(self) -> None:
        self.config = RootConfig().config

    def set_tiktoken_cache_dir_in_env(self, encoding_name: str) -> None:
        """
        encoding_name: cl100k_base, o200k_base
        """
        tiktoken_cache_dir = Path(self.config["tiktoken_cache_dir"][encoding_name])
        tiktoken_cache_dir.resolve()
        if not tiktoken_cache_dir.exists():
            raise TiktokenCacheDirNotExistsError(
                f"TIKTOKEN_CACHE_DIR path {tiktoken_cache_dir} does not exist. Please check..."
            )
        os.environ["TIKTOKEN_CACHE_DIR"] = str(tiktoken_cache_dir)
        print(f"Set TIKTOKEN_CACHE_DIR to {tiktoken_cache_dir}")
